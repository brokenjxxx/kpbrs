const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const path = require('path');

module.exports = async (member, welcomeConfig) => {
  try {
    const guildId = member.guild.id;
    const config = welcomeConfig[guildId];

    if (!config || !config.welcomeChannel) return;

    const channel = member.guild.channels.cache.get(config.welcomeChannel);
    if (!channel) return;

    // Load gambar sebagai attachment
    const imagePath = path.join(__dirname, '..', 'welcomeImages', 'Background.png');
    const attachment = new AttachmentBuilder(imagePath);

    const embed = new EmbedBuilder()
      .setTitle('Selamat datang!')
      .setDescription(`Halo ${member.user.tag}, selamat bergabung di **${member.guild.name}**! 🎉`)
      .setColor('#00FF00')
      .setImage('attachment://Background.png')
      .setTimestamp();

    await channel.send({ embeds: [embed], files: [attachment] });

  } catch (error) {
    console.error('Error di guildMemberAdd:', error);
  }
};
