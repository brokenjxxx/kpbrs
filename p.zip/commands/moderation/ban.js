module.exports = {
  name: 'ban',
  description: 'Ban member dari server',
  category: 'Moderation',
  async execute(message, args) {
    if (!message.member.permissions.has('BanMembers')) {
      return message.reply('Kamu tidak punya izin untuk ban member.');
    }

    const member = message.mentions.members.first();
    if (!member) return message.reply('Sebutkan siapa yang mau di-ban.');

    if (!member.bannable) return message.reply('Aku tidak bisa ban orang itu.');

    const reason = args.slice(1).join(' ') || 'Tidak ada alasan';
    await member.ban({ reason });
    message.channel.send(`${member.user.tag} telah di-ban. Alasan: ${reason}`);
  },
};
