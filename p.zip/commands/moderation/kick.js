module.exports = {
  name: 'kick',
  description: 'Kick member dari server',
  category: 'Moderation',
  async execute(message, args) {
    if (!message.member.permissions.has('KickMembers')) {
      return message.reply('Kamu tidak punya izin untuk kick member.');
    }

    const member = message.mentions.members.first();
    if (!member) return message.reply('Sebutkan siapa yang mau di-kick.');

    if (!member.kickable) return message.reply('Aku tidak bisa kick orang itu.');

    const reason = args.slice(1).join(' ') || 'Tidak ada alasan';
    await member.kick(reason);
    message.channel.send(`${member.user.tag} telah di-kick. Alasan: ${reason}`);
  },
};
