const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const moment = require('moment');

module.exports = {
  name: 'inspect',
  description: 'Menampilkan info user termasuk permission tertinggi, status voice, dan tanggal join server',
  hidden: true,
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
      return message.reply('❌ Kamu harus punya permission untuk menggunakan command ini.');

    let member;
    if (message.mentions.members.size) member = message.mentions.members.first();
    else if (args[0]) {
      try {
        member = await message.guild.members.fetch(args[0]);
      } catch {
        return message.reply('❌ User tidak ditemukan. Pastikan mention atau ID benar.');
      }
    } else return message.reply('❌ Mohon mention user atau berikan ID user yang ingin di-inspect.');

    const permissionPriority = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.MentionEveryone,
      PermissionsBitField.Flags.ManageMessages,
      PermissionsBitField.Flags.ViewAuditLog,
      PermissionsBitField.Flags.MuteMembers,
      PermissionsBitField.Flags.DeafenMembers,
      PermissionsBitField.Flags.MoveMembers,
      PermissionsBitField.Flags.ManageNicknames,
      PermissionsBitField.Flags.ManageEmojisAndStickers,
    ];

    let topPerm = 'Tidak ada permission khusus';
    for (const permFlag of permissionPriority) {
      if (member.permissions.has(permFlag)) {
        topPerm = Object.entries(PermissionsBitField.Flags)
          .find(([_, value]) => value === permFlag)[0]
          .toLowerCase()
          .split('_')
          .map(w => w.charAt(0).toUpperCase() + w.slice(1))
          .join(' ');
        break;
      }
    }

    const topRole = member.roles.highest;
    const roleName = topRole?.id !== message.guild.id ? topRole.name : 'Tidak ada role khusus';

    const createdAt = moment(member.user.createdAt).format('LL');
    const joinedAt = moment(member.joinedAt).format('LL');
    const status = member.presence?.status || 'offline';
    const statusEmoji = {
      online: '🟢',
      idle: '🌙',
      dnd: '⛔',
      offline: '⚫',
    }[status] || '⚫';

    const voiceChannel = member.voice.channel;
    const voiceStatus = voiceChannel ? `🎙️ <#${voiceChannel.id}>` : 'Tidak sedang di Voice Channel';

    const embed = new EmbedBuilder()
      .setColor('#2F3136')
      .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'Username', value: member.user.username, inline: true },
        { name: 'ID', value: member.id, inline: true },
        { name: 'Permission', value: topPerm, inline: true },
        { name: 'Role', value: roleName, inline: true },
        { name: 'Created', value: createdAt, inline: true },
        { name: 'Join', value: joinedAt, inline: true },
        { name: 'Voice', value: voiceStatus, inline: false }
      )
      .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
