const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'avatar',
  description: 'Menampilkan avatar user berdasarkan mention, username, atau ID.',
  category: 'Fun',
  async execute(message, args) {
    let user;

    if (args.length) {
      // Coba ambil dari mention dulu
      user = message.mentions.users.first();

      // Kalau gak ada mention, coba cari berdasarkan ID
      if (!user) {
        try {
          user = await message.client.users.fetch(args[0]);
        } catch {
          // Gagal fetch user
          return message.reply('❌ User tidak ditemukan dengan ID tersebut.');
        }
      }
    } else {
      // Kalau gak ada argumen, ambil user author
      user = message.author;
    }

    const embed = new EmbedBuilder()
      .setTitle(`📸 Avatar dari ${user.tag}`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setColor('#0099ff')
      .setFooter({ text: `ID: ${user.id}` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
