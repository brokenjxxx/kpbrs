// // const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
// // const os = require('os');
// const process = require('process');

// const categoryEmojis = {
//   Moderation: '🛡️',
//   Fun: '🎉',
//   Utility: '⚙️',
//   Music: '🎵',
//   Other: '📁',
// };

// module.exports = {
//   name: 'help',
//   description: 'Menampilkan daftar command dengan tampilan interaktif',

//   async execute(message) {
//     const client = message.client;
//     const botUser = client.user;

//     const uptimeSeconds = process.uptime();
//     const uptime = [
//       Math.floor(uptimeSeconds / 3600),
//       Math.floor((uptimeSeconds % 3600) / 60),
//       Math.floor(uptimeSeconds % 60),
//     ]
//       .map(unit => String(unit).padStart(2, '0'))
//       .join(':');

//     const totalMembers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);

//     // Kategorikan command
//     const categories = {};
//     client.commands.forEach(cmd => {
//       const cat = cmd.category || 'Other';
//       if (!categories[cat]) categories[cat] = [];
//       categories[cat].push(cmd);
//     });

//     // Embed awal (informasi bot + kategori list)
//     const mainEmbed = new EmbedBuilder()
//       .setTitle(`🤖 Tentang ${botUser.username}`)
//       .setDescription(`\
// Hello! Saya **${botUser.username}**.\n\nSaya diciptakan untuk membantu mempermudah Administrator Server dalam mengelola moderasi dan sebagainya!

// Gunakan dropdown di bawah untuk melihat daftar perintah berdasarkan kategori.
// `)
//       .setThumbnail(botUser.displayAvatarURL({ dynamic: true }))
//       .addFields(
//         { name: '🆔 ID Bot', value: botUser.id, inline: true },
//         { name: '📅 Dibuat', value: `<t:${Math.floor(botUser.createdTimestamp / 1000)}:R>`, inline: true },
//         { name: '🌐 Server Aktif', value: `${client.guilds.cache.size}`, inline: true },
//         { name: '📡 Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
//         { name: '⏱️ Aktif Selama', value: `${uptime}`, inline: true },
//         { name: '⚙️ Version', value: `Polka v1` }
//       )
//       .setColor('#00ADEF')
//       .setFooter({ text: `Diminta oleh ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
//       .setTimestamp();

//     // Dropdown menu (select menu) untuk memilih kategori
//     const menuOptions = Object.keys(categories).map(cat => ({
//       label: cat,
//       description: `${categories[cat].length} command di kategori ini`,
//       value: cat,
//       emoji: categoryEmojis[cat] || '📁',
//     }));

//     const row = new ActionRowBuilder().addComponents(
//       new StringSelectMenuBuilder()
//         .setCustomId('help-category')
//         .setPlaceholder('Pilih kategori commands...')
//         .addOptions(menuOptions)
//     );

//     // Kirim embed + select menu
//     const helpMessage = await message.channel.send({ embeds: [mainEmbed], components: [row] });

//     // Filter interaksi hanya dari user yang menjalankan command
//     const filter = i => i.user.id === message.author.id && i.customId === 'help-category';

//     const collector = helpMessage.createMessageComponentCollector({ filter, time: 60000 });

//     collector.on('collect', async interaction => {
//       const selectedCategory = interaction.values[0];
//       const cmds = categories[selectedCategory];

//       // Buat embed command dalam kategori terpilih
//       const categoryEmbed = new EmbedBuilder()
//         .setTitle(`${categoryEmojis[selectedCategory] || '📁'} Help: ${selectedCategory}`)
//         .setDescription(`Daftar perintah di kategori **${selectedCategory}**:`)
//         .setColor('#00BFFF')
//         .setFooter({ text: `Diminta oleh ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
//         .setThumbnail(botUser.displayAvatarURL())
//         .setTimestamp();

//       cmds.forEach(cmd => {
//         categoryEmbed.addFields({
//           name: `\`${client.config.prefix}${cmd.name}\``,
//           value: cmd.description || 'Tidak ada deskripsi',
//           inline: false,
//         });
//       });

//       // Update pesan dengan embed baru (tanpa ubah select menu)
//       await interaction.update({ embeds: [categoryEmbed] });
//     });

//     collector.on('end', collected => {
//       // Setelah 60 detik, disable menu
//       const disabledRow = new ActionRowBuilder().addComponents(
//         row.components[0].setDisabled(true)
//       );
//       helpMessage.edit({ components: [disabledRow] });
//     });
//   },
// };
