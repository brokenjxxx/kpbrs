const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  name: 'roleselect',
  description: 'Menampilkan menu dropdown untuk memilih role (prefix command).',
  category: 'Utility',

  async execute(message, args) {
    // Ganti dengan role ID asli di servermu
    const roles = [
      { label: 'Gamer', description: 'Dapat akses channel game', roleId: 'ROLE_ID_GAMER' },
      { label: 'Musician', description: 'Dapat akses channel musik', roleId: 'ROLE_ID_MUSICIAN' },
      { label: 'Artist', description: 'Dapat akses channel seni', roleId: 'ROLE_ID_ARTIST' },
      { label: 'asd', description: 'Dapat akses channel seni', roleId: 'asd' },
      
    ];

    const options = roles.map(r => ({
      label: r.label,
      description: r.description,
      value: r.roleId,
    }));

    const embed = new EmbedBuilder()
      .setTitle('🎭 Pilih Role Kamu')
      .setDescription('Gunakan menu dropdown di bawah untuk memilih role.\n\n**Note:** Kamu hanya bisa memilih satu role dalam satu waktu.')
      .setColor('#0099ff')
      .setThumbnail(message.guild.iconURL())
      .setFooter({ text: 'Role akan otomatis diberikan atau dihapus ketika dipilih', iconURL: message.client.user.displayAvatarURL() });

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('select-role')
        .setPlaceholder('Pilih role...')
        .addOptions(options)
    );

    await message.channel.send({ embeds: [embed], components: [row] });
  },
};
