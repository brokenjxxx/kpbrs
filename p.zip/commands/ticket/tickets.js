const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const { category } = require('../general/afk');

module.exports = {
  name: 'tickets',
  description: 'Penggunaan : tickets setup <id category>',
  category: 'Utility', 
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return message.reply('❌ Kamu tidak punya izin Manage Server untuk menggunakan command ini.');
    }

    if (args.length === 0) {
      return message.reply('❌ Harap berikan ID kategori. Contoh: `..tickets setup 123456789012345678`');
    }

    const subCommand = args[0].toLowerCase();
    if (subCommand !== 'setup') {
      return message.reply('❌ Sub-command tidak dikenal. Gunakan `..tickets setup <categoryID>`');
    }

    const categoryId = args[1];
    if (!categoryId) {
      return message.reply('❌ Harap berikan ID kategori.');
    }

    const category = message.guild.channels.cache.get(categoryId);
    if (!category || category.type !== 4) { // 4 = GUILD_CATEGORY
      return message.reply('❌ ID kategori tidak valid atau bukan kategori.');
    }

    // Simpan config ticket ke file ticketConfig.json
    let ticketConfig = {};
    const path = './ticketConfig.json';

    try {
      if (fs.existsSync(path)) {
        const data = fs.readFileSync(path, 'utf8');
        ticketConfig = data ? JSON.parse(data) : {};
      }
    } catch (error) {
      console.error('Error membaca ticketConfig.json:', error);
    }

    ticketConfig[message.guild.id] = { categoryId };

    try {
      fs.writeFileSync(path, JSON.stringify(ticketConfig, null, 2));
    } catch (error) {
      console.error('Error menulis ticketConfig.json:', error);
      return message.reply('❌ Gagal menyimpan konfigurasi ticket.');
    }

    // Buat tombol ticket
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('🎫 Create')
        .setStyle(ButtonStyle.Primary),
    );

    // Kirim embed konfirmasi sistem ticket sudah aktif
    const embed = new EmbedBuilder()
      .setTitle('🎟️Ticket Support')
      .setDescription(`Sistem tiket aktif, silahkan membuat tiket.\n\nKlik tombol di bawah untuk membuat tiket baru.`)
      .setColor(0x00AE86)
      .setFooter({ text: 'Polka Bot | Est.2025' })
      .setTimestamp();

    await message.channel.send({ embeds: [embed], components: [row] });
  },
};
