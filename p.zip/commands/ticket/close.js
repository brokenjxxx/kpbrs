// commands/close.js

const fs = require('fs');
const ticketsPath = './data/tickets.json';

module.exports = {
  name: 'close',
  description: 'Menutup tiket.',
  hidden: true,
  async execute(message) {
    const channel = message.channel;
    const userId = Object.keys(require(ticketsPath)).find(id => require(ticketsPath)[id] === channel.id);

    if (!userId) return message.reply('❌ Channel ini bukan tiket yang valid.');

    await channel.send('📪 Tiket ditutup. Channel akan dihapus dalam 5 detik...');
    setTimeout(() => {
      channel.delete().catch(err => console.error('Gagal menghapus channel:', err));
    }, 5000);

    const data = JSON.parse(fs.readFileSync(ticketsPath));
    delete data[userId];
    fs.writeFileSync(ticketsPath, JSON.stringify(data, null, 2));
  },
};
