module.exports = {
  name: 'say',
  category: 'Fun',
  description: 'Bot akan mengulang pesan yang kamu berikan.',
  execute(message, args) {
    const text = args.join(' ');
    if (!text) return message.reply('❌ Masukkan teks untuk diulang!');
    
    message.delete().catch(() => {});
    message.channel.send(text);
  }
};