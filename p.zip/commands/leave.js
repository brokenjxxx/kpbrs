const { getVoiceConnection } = require('@discordjs/voice');
const { category } = require('./afk');

module.exports = {
  name: 'leave',
  description: 'Keluar dari voice channel',
  category: 'Fun',
  execute(message, args) {
    const connection = getVoiceConnection(message.guild.id);
    if (connection) {
      connection.destroy();
      message.reply('👋 Keluar dari voice channel.');
    } else {
      message.reply('❌ Bot tidak sedang berada di voice channel.');
    }
  }
};
