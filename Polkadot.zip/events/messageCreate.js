const { PermissionsBitField } = require("discord.js");
const fs = require("fs");
const path = require("path");

const afkPath = path.resolve("./data/afk.json");

function loadAfkData() {
  try {
    return JSON.parse(fs.readFileSync(afkPath, "utf8"));
  } catch {
    return {};
  }
}

function saveAfkData(data) {
  fs.writeFileSync(afkPath, JSON.stringify(data, null, 2));
}

module.exports = {
  name: "messageCreate",
  async execute(client, message) {
    try {
      if (!message || !message.author) return;
      if (message.author.bot) return;

      console.log(`[${message.guild?.name || "DM"}] ${message.author.tag}: ${message.content}`);

      // === ⚠️ ANTI INVITE ===
      const inviteRegex = /(discord\.gg|discordapp\.com\/invite)/i;
      if (inviteRegex.test(message.content)) {
        try {
          const whitelistPath = "./data/whitelist.json";
          let whitelist = { users: [], roles: [] };

          if (fs.existsSync(whitelistPath)) {
            whitelist = JSON.parse(fs.readFileSync(whitelistPath, "utf8"));
          }

          const isWhitelistedUser = whitelist.users.includes(message.author.id);
          const isWhitelistedRole = message.member?.roles?.cache?.some(r =>
            whitelist.roles.includes(r.id)
          );

          if (!isWhitelistedUser && !isWhitelistedRole) {
            await message.delete();

            if (!client.inviteViolations) client.inviteViolations = new Map();
            const userId = message.author.id;
            const currentViolations = (client.inviteViolations.get(userId) || 0) + 1;
            client.inviteViolations.set(userId, currentViolations);

            if (currentViolations === 1) {
              await message.channel.send(
                `⚠️ <@${userId}>, kamu tidak diperkenankan untuk mengirim link server lain!`
              );
            } else if (currentViolations === 2) {
              const member = message.guild.members.cache.get(userId);
              if (member)
                await member.timeout(5 * 60 * 1000, "Kirim link server lain (2x)");
              await message.channel.send(`⛔ <@${userId}> telah di-timeout selama 5 menit.`);
            } else if (currentViolations >= 3) {
              const member = message.guild.members.cache.get(userId);
              if (member)
                await member.timeout(24 * 60 * 60 * 1000, "Kirim link server lain (3x)");
              await message.channel.send(`🚫 <@${userId}> telah di-timeout selama 1 hari.`);
              client.inviteViolations.set(userId, 0);
            }
          }
        } catch (error) {
          console.error("❌ Error di fitur anti-invite:", error);
        }
      }

      // === 💬 FITUR AFK ===
      const afkCommand = client.commands.get("afk");
      if (!afkCommand) return;

      // Sinkronkan data dari file
      const afkData = loadAfkData();
      for (const [id, data] of Object.entries(afkData)) {
        if (!afkCommand.afkMap.has(id)) afkCommand.afkMap.set(id, data);
      }

      const prefix = client.config?.prefix || "!";
      const content = message.content.toLowerCase();

      // Jangan nonaktifkan AFK kalau baru mengetik command afk
      if (content.startsWith(`${prefix}afk`)) return;

      // 🔹 Notifikasi AFK saat user disebut (hindari duplikat)
      const uniqueMentions = [...new Set(message.mentions.users.map(u => u.id))];
      for (const userId of uniqueMentions) {
        const afk = afkCommand.afkMap.get(userId);
        if (afk) {
          const user = await client.users.fetch(userId);
          await message.channel.send(`📴 ${user.tag} sedang AFK — ${afk.reason}`);
        }
      }

      // 🔹 Hapus status AFK kalau user kirim pesan biasa
      if (afkCommand.afkMap.has(message.author.id)) {
        afkCommand.afkMap.delete(message.author.id);
        delete afkData[message.author.id];
        saveAfkData(afkData);

        await message.reply("✅ Status AFK kamu telah dinonaktifkan.");
      }
    } catch (error) {
      console.error("❌ Error di event messageCreate:", error);
    }
  },
};
