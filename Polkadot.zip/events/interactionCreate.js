const ticketButtonHandler = require("../interactions/ticketButton");

module.exports = {
  name: "interactionCreate",
  async execute(client, interaction) {
    try {
      // Pastikan interaction valid
      if (!interaction || typeof interaction !== "object") return;

      // === STRING SELECT MENU ===
      if (interaction.isStringSelectMenu?.()) {
        if (interaction.customId === "select-role") {
          const selectedRoleId = interaction.values[0];
          const role = interaction.guild.roles.cache.get(selectedRoleId);
          const member = interaction.member;

          if (!role) {
            return interaction.reply({
              content: "❌ Role tidak ditemukan.",
              ephemeral: true,
            });
          }

          try {
            if (member.roles.cache.has(role.id)) {
              await member.roles.remove(role);
              await interaction.reply({
                content: `✅ Role **${role.name}** telah dihapus dari kamu.`,
                ephemeral: true,
              });
            } else {
              await member.roles.add(role);
              await interaction.reply({
                content: `✅ Role **${role.name}** berhasil diberikan!`,
                ephemeral: true,
              });
            }
          } catch (err) {
            console.error("❌ Error mengatur role:", err);
            return interaction.reply({
              content: "❌ Gagal mengubah role. Pastikan bot punya izin yang cukup.",
              ephemeral: true,
            });
          }
        }
      }

      // === BUTTON INTERACTION ===
      else if (interaction.isButton?.()) {
        if (ticketButtonHandler && typeof ticketButtonHandler.execute === "function") {
          await ticketButtonHandler.execute(interaction, client);
        }
      }

      // === MODAL INTERACTION ===
      else if (interaction.isModalSubmit?.()) {
        // nanti bisa kamu tambahkan handler modal di sini
        console.log("Modal submit:", interaction.customId);
      }

      // === CHAT INPUT COMMAND (slash command) ===
      else if (interaction.isChatInputCommand?.()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
          await command.execute(interaction, client);
        } catch (error) {
          console.error(error);
          if (interaction.replied || interaction.deferred)
            await interaction.followUp({ content: "⚠️ Error saat menjalankan command.", ephemeral: true });
          else
            await interaction.reply({ content: "⚠️ Error saat menjalankan command.", ephemeral: true });
        }
      }
    } catch (error) {
      console.error("💥 Error di interactionCreate:", error);
    }
  },
};
