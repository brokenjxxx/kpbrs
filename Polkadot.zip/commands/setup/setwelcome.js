const fs = require('fs');

module.exports = {
  name: 'setwelcome',
  description: 'Mengatur channel untuk pesan selamat datang.',
  category: 'Utility',
  async execute(message, args, welcomeConfig, welcomeConfigPath) {
    if (!message.member.permissions.has('ManageChannels')) {
      return message.reply('❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.');
    }

    const channel = message.mentions.channels.first();
    if (!channel) {
      return message.reply('❌ Tolong mention channel yang ingin digunakan untuk welcome.');
    }

    const guildId = message.guild.id;
    if (!welcomeConfig[guildId]) {
      welcomeConfig[guildId] = {};
    }

    welcomeConfig[guildId].welcomeChannel = channel.id;

    // Simpan ke file welcomeConfig.json
    try {
      fs.writeFileSync(welcomeConfigPath, JSON.stringify(welcomeConfig, null, 4));
      message.reply(`✅ Channel welcome telah diatur ke ${channel}.`);
    } catch (error) {
      console.error('Error saat menyimpan welcomeConfig:', error);
      message.reply('⚠️ Terjadi kesalahan saat menyimpan konfigurasi welcome.');
    }
  }
};