const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'prefix',
  description: 'Mengatur prefix bot.',
  category: 'Utility',
  async execute(message, args, config, configPath) {
    if (!args.length) {
      return message.reply('❌ Harap masukkan prefix baru. Contoh: `!prefix !`');
    }

    const newPrefix = args[0];

    // Update prefix di memori (config yang dipassing dari index.js)
    config.prefix = newPrefix;

    try {
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      message.reply(`✅ Prefix berhasil diubah menjadi \`${newPrefix}\``);
    } catch (error) {
      console.error('Error menulis config.json:', error);
      message.reply('⚠️ Gagal mengubah prefix.');
    }
  },
};