module.exports = {
  name: 'message',
  description: 'Mengirim DM ke user lewat mention atau ID (hanya untuk yang punya izin Manage Channels)',
  category: 'Utility',
  async execute(message, args) {
    // Cek izin pengguna
    if (!message.member.permissions.has('ManageChannels')) {
      return message.channel.send('❌ Kamu tidak punya izin untuk menggunakan perintah ini.');
    }

    if (args.length < 2) {
      return message.channel.send('Format salah. Gunakan: `!message @user|userID isi pesan`');
    }

    const targetArg = args[0];
    const content = args.slice(1).join(' ');

    let user;

    // Coba ambil user dari mention
    if (message.mentions.users.size > 0) {
      user = message.mentions.users.first();
    } else {
      // Coba ambil user dari ID
      try {
        user = await message.client.users.fetch(targetArg);
      } catch (err) {
        console.error('Gagal fetch user:', err);
        return message.channel.send('❌ User tidak ditemukan. Pastikan ID benar.');
      }
    }

    if (!user) {
      return message.channel.send('❌ User tidak ditemukan.');
    }

    try {
      await user.send(content);
      await message.channel.send(`✅ Pesan berhasil dikirim ke **${user.tag}**`);
    } catch (err) {
      console.error('Gagal kirim DM:', err);
      await message.channel.send('❌ Gagal mengirim DM. Mungkin user menonaktifkan DM dari server.');
    }
  }
};e