const fs = require("fs");
const path = require("path");
const whitelistPath = path.join(__dirname, "../data/whitelist.json");

if (!fs.existsSync(whitelistPath)) {
  fs.writeFileSync(whitelistPath, JSON.stringify({ users: [], roles: [] }, null, 2));
}

const userWarnings = new Map();

module.exports = async (client, message) => {
  const inviteRegex = /(https?:\/\/)?(www\.)?(discord\.gg|discord\.com\/invite)\/[a-zA-Z0-9]+/;
  if (!inviteRegex.test(message.content)) return;

  const whitelist = JSON.parse(fs.readFileSync(whitelistPath));
  if (whitelist.users.includes(message.author.id)) return;
  if (message.member.roles.cache.some((r) => whitelist.roles.includes(r.id))) return;

  await message.delete().catch(() => {});

  const warns = (userWarnings.get(message.author.id) || 0) + 1;
  userWarnings.set(message.author.id, warns);

  if (warns === 1) {
    message.channel.send(`⚠️ <@${message.author.id}>, kamu **tidak diperkenankan** mengirim link server lain! (Peringatan 1)`);
  } else if (warns === 2) {
    try {
      await message.member.timeout(5 * 60 * 1000, "Peringatan ke-2 (link Discord)");
      message.channel.send(`⏰ <@${message.author.id}> di-timeout **5 menit**.`);
    } catch (e) {
      console.error(e);
    }
  } else if (warns >= 3) {
    try {
      await message.member.timeout(24 * 60 * 60 * 1000, "Peringatan ke-3 (link Discord)");
      message.channel.send(`🚫 <@${message.author.id}> di-timeout **1 hari**.`);
      userWarnings.set(message.author.id, 0);
    } catch (e) {
      console.error(e);
    }
  }
};
