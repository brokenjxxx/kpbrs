const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  entersState,
  VoiceConnectionStatus,
} = require('@discordjs/voice');
const ytdl = require('ytdl-core');
const playdl = require('play-dl'); // dipakai untuk fitur search YouTube

module.exports = {
  name: 'play',
  description: 'Putar musik dari YouTube!',
  category: 'Fun',

  async execute(message, args) {
    // 🔹 Cek argumen
    if (!args.length)
      return message.reply('❌ Masukkan judul lagu atau link YouTube.');

    // 🔹 Cek voice channel
    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel)
      return message.reply('❌ Kamu harus berada di voice channel.');

    // 🔹 Gabung ke voice channel
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator,
    });

    try {
      // Tunggu sampai koneksi siap
      await entersState(connection, VoiceConnectionStatus.Ready, 30_000);

      const query = args.join(' ');
      let videoUrl;
      let videoTitle;

      // 🔍 Kalau input adalah link YouTube langsung
      const validate = playdl.yt_validate(query);
      if (validate === 'video') {
        const info = await ytdl.getInfo(query);
        videoUrl = info.videoDetails.video_url;
        videoTitle = info.videoDetails.title;
      } else {
        // 🔍 Kalau input teks biasa → cari di YouTube
        const searchResults = await playdl.search(query, { limit: 1 });
        if (!searchResults.length)
          return message.reply('❌ Lagu tidak ditemukan.');

        const video = searchResults[0];
        videoUrl = `https://www.youtube.com/watch?v=${video.id}`;
        videoTitle = video.title;
      }

      console.log('🎧 Stream dari:', videoUrl);

      // 🔊 Buat stream audio pakai ytdl-core
      const stream = ytdl(videoUrl, {
        filter: 'audioonly',
        quality: 'highestaudio',
        highWaterMark: 1 << 25, // buffer besar biar lancar
      });

      const resource = createAudioResource(stream);
      const player = createAudioPlayer();

      connection.subscribe(player);
      player.play(resource);

      // 🎵 Event: mulai memutar lagu
      player.on(AudioPlayerStatus.Playing, () => {
        message.channel.send(`🎶 Memutar: **${videoTitle}**`);
      });

      // 🔚 Event: selesai memutar lagu
      player.on(AudioPlayerStatus.Idle, () => {
        connection.destroy();
      });

      // ⚠️ Event: kalau ada error di player
      player.on('error', (error) => {
        console.error('Player error:', error);
        message.channel.send('❌ Terjadi error saat memutar audio.');
      });
    } catch (err) {
      console.error('Gagal join / play:', err);
      message.reply('❌ Gagal memutar lagu.');
    }
  },
};
