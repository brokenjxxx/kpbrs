module.exports = {
  name: 'hello',
  description: 'Sapa pengguna',
  category: 'Fun',
  execute(message, args) {
    message.reply(`Halo, ${message.author.username}! 👋`);
  }
};
