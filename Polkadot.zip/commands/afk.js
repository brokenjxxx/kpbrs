const afkMap = new Map();

module.exports = {
  name: 'afk',
  description: 'Aktifkan status AFK dengan alasan tertentu.',
  category: 'Utility',
  afkMap,
  async execute(message, args) {
    const reason = args.join(' ') || 'Tidak ada alasan.';
    afkMap.set(message.author.id, {
      reason,
      timestamp: Date.now()
    });

    message.reply(`📴 Kamu sekarang dalam mode AFK. Alasan: *${reason}*`);
  },
};
