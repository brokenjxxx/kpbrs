// commands/create-ticket.js

const fs = require('fs');
const path = require('path');
const { PermissionFlagsBits } = require('discord.js');
const { category } = require('./afk');

module.exports = {
  name: 'create-ticket',
  description: 'Membuka tiket bantuan.',
  category: 'Utility',
  hidden: true,
  async execute(message) {
    const user = message.author;
    const guild = message.guild;

    const configPath = './data/tickets-config.json';
    const ticketsPath = './data/tickets.json';

    if (!fs.existsSync(configPath)) {
      return message.reply('❌ Sistem ticket belum disiapkan. Gunakan `!tickets setup <id_kategori>` terlebih dahulu.');
    }

    const config = JSON.parse(fs.readFileSync(configPath));
    const categoryId = config[guild.id]?.categoryId;

    if (!categoryId) {
      return message.reply('❌ Tidak ada kategori yang diatur untuk tiket.');
    }

    let ticketData = {};
    if (fs.existsSync(ticketsPath)) {
      ticketData = JSON.parse(fs.readFileSync(ticketsPath));
    }

    if (ticketData[user.id]) {
      return message.reply('❗ Kamu sudah memiliki tiket aktif.');
    }

    const category = guild.channels.cache.get(categoryId);
    if (!category) {
      return message.reply('❌ Kategori tidak ditemukan.');
    }

    // Cari role dengan permission ManageChannels
    const staffRoles = guild.roles.cache.filter(role =>
      role.permissions.has(PermissionFlagsBits.ManageChannels)
    );

    // Permission settings
    const permissionOverwrites = [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
    ];

    staffRoles.forEach(role => {
      permissionOverwrites.push({
        id: role.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      });
    });

    const ticketChannel = await guild.channels.create({
      name: `ticket-${user.username}`.toLowerCase(),
      type: 0, // Text channel
      parent: category.id,
      permissionOverwrites,
    });

    ticketData[user.id] = ticketChannel.id;
    fs.writeFileSync(ticketsPath, JSON.stringify(ticketData, null, 2));

    ticketChannel.send(`🎫 Halo <@${user.id}>, silakan jelaskan masalahmu di sini.\nStaff akan segera membantu.\nKetik \`!close\` untuk menutup tiket.`);
    message.reply(`✅ Tiket berhasil dibuat: <#${ticketChannel.id}>`);
  },
};
