const { EmbedBuilder } = require('discord.js');
const puppeteer = require('puppeteer-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();

puppeteer.use(stealth);

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36';

module.exports = {
  name: 'adbypass',
  description: 'Check Linkvertise status (UI like bypass.vip)',
  async execute(message, args) {
    try {
      // ===== VALIDATION =====
      if (!args[0] || !args[0].includes('linkvertise.com')) {
        return message.reply('❌ Masukkan link Linkvertise yang valid.');
      }

      const url = args[0];

      // ===== LOADING EMBED (PASTI DIKIRIM) =====
      const loadingEmbed = new EmbedBuilder()
        .setTitle('🔎 Checking Linkvertise...')
        .setDescription('Analyzing link, please wait...')
        .setColor(0xf1c40f)
        .addFields({ name: 'URL', value: url })
        .setTimestamp();

      const msg = await message.reply({ embeds: [loadingEmbed] });

      // ===== SAFE LAUNCH =====
      let browser;
      try {
        browser = await puppeteer.launch({
          headless: 'new',
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage'
          ]
        });
      } catch (err) {
        console.error('[lvcheck] Puppeteer launch failed:', err);

        const failEmbed = new EmbedBuilder()
          .setTitle('⚠️ Linkvertise Checker')
          .setColor(0xe74c3c)
          .setDescription('Gagal menjalankan browser (Puppeteer).')
          .addFields(
            { name: 'Status', value: '**ERROR**' },
            { name: 'Reason', value: 'Chromium tidak tersedia / sandbox error' }
          )
          .setTimestamp();

        return msg.edit({ embeds: [failEmbed] });
      }

      let status = {
        timer: false,
        captcha: false,
        paid: false
      };

      try {
        const page = await browser.newPage();
        await page.setUserAgent(USER_AGENT);
        await page.setDefaultNavigationTimeout(20000);

        await page.goto(url, { waitUntil: 'domcontentloaded' });

        // ===== DETECTION =====
        if (
          await page.$(
            'iframe[src*="captcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"]'
          )
        ) {
          status.captcha = true;
        }

        const content = await page.content();

        if (/wait|seconds|continue|timer/i.test(content)) {
          status.timer = true;
        }

        if (/premium|paid|upgrade|subscribe/i.test(content)) {
          status.paid = true;
        }

        await page.close();
      } catch (err) {
        console.error('[lvcheck] Page error:', err);
      } finally {
        await browser.close();
      }

      // ===== STATUS LOGIC =====
      let finalStatus = 'OPEN';
      let color = 0x2ecc71;
      let confidence = '80%';

      if (status.captcha) {
        finalStatus = 'CAPTCHA DETECTED';
        color = 0xe74c3c;
        confidence = '0%';
      } else if (status.paid) {
        finalStatus = 'PAID GATE';
        color = 0x9b59b6;
        confidence = '0%';
      } else if (status.timer) {
        finalStatus = 'TIMER REQUIRED';
        color = 0xf39c12;
        confidence = '10%';
      }

      // ===== FINAL EMBED =====
      const resultEmbed = new EmbedBuilder()
        .setTitle('🔓 Linkvertise Checker')
        .setColor(color)
        .addFields(
          { name: 'Status', value: `**${finalStatus}**` },
          {
            name: 'Details',
            value:
              `• Timer: ${status.timer ? 'YES' : 'NO'}\n` +
              `• CAPTCHA: ${status.captcha ? 'YES' : 'NO'}\n` +
              `• Paid Gate: ${status.paid ? 'YES' : 'NO'}`
          },
          { name: 'Confidence', value: confidence }
        )
        .setFooter({ text: 'UI inspired by bypass.vip (status only)' })
        .setTimestamp();

      await msg.edit({ embeds: [resultEmbed] });
    } catch (fatal) {
      console.error('[lvcheck] Fatal error:', fatal);
      return message.reply('❌ Terjadi error internal. Cek console.');
    }
  }
};
