const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const process = require('process');

const categoryEmojis = {
  Moderation: '🛡️',
  Fun: '🎉',
  Utility: '⚙️',
  Music: '🎵',
  Other: '📁',
};

module.exports = {
  name: 'bot',
  description: 'Menampilkan daftar command dengan tampilan interaktif',
  category: 'Utility',

  async execute(message) {
    const client = message.client;
    const botUser = client.user;

    // Hitung uptime bot dalam hh:mm:ss
    const uptimeSeconds = process.uptime();
    const uptime = [
      Math.floor(uptimeSeconds / 3600),
      Math.floor((uptimeSeconds % 3600) / 60),
      Math.floor(uptimeSeconds % 60),
    ]
      .map(unit => String(unit).padStart(2, '0'))
      .join(':');

    // Kategorikan command, skip command yang hidden
    const categories = {};
    client.commands.forEach(cmd => {
      if (cmd.hidden) return;
      const cat = cmd.category || 'Other';
      if (!categories[cat]) categories[cat] = [];
      categories[cat].push(cmd);
    });

    // Embed utama
    const mainEmbed = new EmbedBuilder()
      .setTitle(`🤖 About ${botUser.username}`)
      .setDescription(`\
Hai! Saya **${botUser.username}**.\n\nSaya diciptakan untuk membantu mempermudah Administrator Server dalam mengelola moderasi dan sebagainya!

Gunakan dropdown di bawah untuk melihat daftar perintah berdasarkan kategori.
`)
      .setThumbnail(botUser.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🆔 ID Bot', value: botUser.id, inline: true },
        { name: '📅 Dibuat', value: `<t:${Math.floor(botUser.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '🌐 Server Aktif', value: `${client.guilds.cache.size}`, inline: true },
        { name: '📡 Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
        { name: '⏱️ Aktif Selama', value: uptime, inline: true },
        { name: '⚙️ Bot Versi', value: `v1` }
      )
      .setColor('#00ADEF')
      .setFooter({ text: `Diminta oleh ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      .setTimestamp();

    // Persiapkan dropdown options dari kategori
    const menuOptions = Object.keys(categories).map(cat => ({
      label: cat,
      description: `${categories[cat].length} command di kategori ini`,
      value: cat,
      emoji: categoryEmojis[cat] || '📁',
    }));

    if (menuOptions.length === 0) {
      return message.channel.send('❌ Tidak ada command yang tersedia saat ini.');
    }

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('help-category')
        .setPlaceholder('Pilih kategori command...')
        .addOptions(menuOptions)
    );

    const helpMessage = await message.channel.send({ embeds: [mainEmbed], components: [row] });

    // Filter interaksi
    const filter = i => i.user.id === message.author.id && i.customId === 'help-category';

    const collector = helpMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async interaction => {
      try {
        console.log('Interaction diterima:', interaction.values[0]);

        const selectedCategory = interaction.values[0];
        const cmds = categories[selectedCategory];

        if (!cmds || cmds.length === 0) {
          return interaction.reply({ content: '❌ Kategori ini kosong.', ephemeral: true });
        }

        const categoryEmbed = new EmbedBuilder()
          .setTitle(`${categoryEmojis[selectedCategory] || '📁'} Category: ${selectedCategory}`)
          .setDescription(`Daftar perintah di kategori **${selectedCategory}**:`)
          .setColor('#00BFFF')
          .setFooter({ text: `Diminta oleh ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
          .setThumbnail(botUser.displayAvatarURL())
          .setTimestamp();

        cmds.forEach(cmd => {
          categoryEmbed.addFields({
            name: `\`${(client.config?.prefix || '!') + cmd.name}\``,
            value: cmd.description || 'Tidak ada deskripsi',
            inline: false,
          });
        });

        await interaction.update({ embeds: [categoryEmbed] });
      } catch (error) {
        console.error('Error saat interaction collect:', error);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: '⚠️ Terjadi kesalahan saat memproses permintaan.', ephemeral: true });
        }
      }
    });

    collector.on('end', () => {
      // Disable select menu setelah 60 detik
      const disabledRow = new ActionRowBuilder().addComponents(
        row.components[0].setDisabled(true)
      );
      helpMessage.edit({ components: [disabledRow] }).catch(() => null);
    });
  },
};
