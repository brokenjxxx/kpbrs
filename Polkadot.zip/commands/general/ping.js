module.exports = {
  name: 'ping',
  category: 'Utility',
  description: 'Cek respons bot',
  execute(message, args) {
    message.reply('🏓 Pong!');
  }
};
