const fs = require("fs");
const path = require("path");

module.exports = {
  name: "whitelist",
  description: "Menampilkan daftar user & role yang di-whitelist.",
  async execute(message) {
    if (!message.guild)
      return message.reply("❌ Command ini hanya bisa digunakan di dalam server.");
    if (!message.member)
      return message.reply("⚠️ Terjadi error: data member tidak ditemukan.");
    if (!message.member.permissions.has("Administrator"))
      return message.reply("❌ Kamu tidak memiliki izin Administrator.");

    const whitelistPath = path.join(__dirname, "../../data/whitelist.json");

    if (!fs.existsSync(whitelistPath)) {
      return message.reply("⚠️ Belum ada data whitelist.");
    }

    const whitelist = JSON.parse(fs.readFileSync(whitelistPath, "utf8") || "{}");
    const users = (whitelist.users || []).map((id) => `<@${id}>`).join(", ") || "Tidak ada";
    const roles = (whitelist.roles || []).map((id) => `<@&${id}>`).join(", ") || "Tidak ada";

    return message.channel.send({
      embeds: [
        {
          title: "📜 Daftar Whitelist",
          color: 0x00ff99,
          fields: [
            { name: "👤 Users", value: users },
            { name: "🏷️ Roles", value: roles },
          ],
          footer: { text: "Whitelist System by PolkaBot" },
        },
      ],
    });
  },
};
