const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'showmembers',
  description: 'Menampilkan semua member beserta role tertingginya, diurutkan dari atas dengan pagination.',
  category: 'Utility',
  async execute(message) {
    try {
      // Cek permission bot di channel ini
      const permissions = message.channel.permissionsFor(message.guild.members.me);
      if (!permissions.has(PermissionsBitField.Flags.AddReactions) ||
          !permissions.has(PermissionsBitField.Flags.ManageMessages) ||
          !permissions.has(PermissionsBitField.Flags.ReadMessageHistory)) {
        return message.channel.send('❌ Saya butuh permission `Add Reactions`, `Manage Messages`, dan `Read Message History` di channel ini!');
      }

      await message.guild.members.fetch();

      const members = message.guild.members.cache
        .filter(member => !member.user.bot)
        .map(member => {
          const highestRole = member.roles.highest;
          return {
            username: member.user.tag,
            role: highestRole.name,
            rolePosition: highestRole.position,
          };
        })
        .sort((a, b) => b.rolePosition - a.rolePosition);

      if (members.length === 0) {
        return message.channel.send('Tidak ada member yang ditemukan.');
      }

      const pageSize = 10;
      let currentPage = 0;
      const totalPages = Math.ceil(members.length / pageSize);

      const generateEmbed = (page) => {
        const start = page * pageSize;
        const current = members.slice(start, start + pageSize);

        const description = current
          .map((m, i) => `${start + i + 1}. ${m.username} (${m.role})`)
          .join('\n');

        return new EmbedBuilder()
          .setTitle(`📋 Daftar Member (Page ${page + 1} / ${totalPages})`)
          .setDescription(description)
          .setColor('Blue')
          .setFooter({ text: `Total member: ${members.length}` });
      };

      const embedMessage = await message.channel.send({ embeds: [generateEmbed(currentPage)] });

      if (totalPages <= 1) return; // Kalau cuma 1 halaman, gak perlu reaction

      await embedMessage.react('◀️');
      await embedMessage.react('▶️');

      const filter = (reaction, user) =>
        ['◀️', '▶️'].includes(reaction.emoji.name) && user.id === message.author.id;

      const collector = embedMessage.createReactionCollector({ filter, time: 120000 });

      collector.on('collect', async (reaction, user) => {
        try {
          await reaction.users.remove(user);
        } catch {}

        if (reaction.emoji.name === '▶️') {
          if (currentPage < totalPages - 1) {
            currentPage++;
            await embedMessage.edit({ embeds: [generateEmbed(currentPage)] });
          }
        } else if (reaction.emoji.name === '◀️') {
          if (currentPage > 0) {
            currentPage--;
            await embedMessage.edit({ embeds: [generateEmbed(currentPage)] });
          }
        }
      });

      collector.on('end', () => {
        embedMessage.reactions.removeAll().catch(() => {});
      });

    } catch (err) {
      console.error(err);
      message.reply('❌ Terjadi error saat mengambil daftar member.');
    }
  },
};
