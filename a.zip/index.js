const {
  Client,
  GatewayIntentBits,
  Collection,
  PermissionsBitField,
} = require("discord.js");
const { getVoiceConnection } = require("@discordjs/voice");
const fs = require("fs");
const path = require("path");

// ================= CONFIG =================
const configPath = "./config.json";
const config = require(configPath);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

client.commands = new Collection();
client.config = config;

// ================= LOAD COMMANDS (Support Subfolder) =================
function loadCommands(dir = "./commands") {
  const files = fs.readdirSync(dir);

  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.lstatSync(fullPath);

    if (stat.isDirectory()) {
      loadCommands(fullPath); // Rekursif
    } else if (file.endsWith(".js")) {
      try {
        const command = require(path.resolve(fullPath)); // ✅ Fix path Windows

        // ✅ Skip jika bukan command (misal utils/helper)
        if (!command.name || typeof command.execute !== "function") {
          console.warn(`⚠️ Lewati file non-command: ${file}`);
          continue;
        }

        client.commands.set(command.name, command);
      } catch (err) {
        console.error(`❌ Gagal load command ${file}:`, err.message);
      }
    }
  }
}
loadCommands();

// ================= WELCOME CONFIG =================
const welcomeConfigPath = "./welcomeConfig.json";
let welcomeConfig = {};
try {
  if (fs.existsSync(welcomeConfigPath)) {
    const data = fs.readFileSync(welcomeConfigPath, "utf8");
    welcomeConfig = data ? JSON.parse(data) : {};
  } else {
    fs.writeFileSync(welcomeConfigPath, JSON.stringify({}));
  }
} catch (error) {
  console.error("Error reading welcomeConfig.json:", error);
  welcomeConfig = {};
}

// ================= EVENT HANDLERS =================
const guildMemberAdd = require("./events/guildMemberAdd");
const guildMemberRemove = require("./events/guildMemberRemove");

client.once("ready", () => {
  console.log(`✅ Bot aktif sebagai ${client.user.tag}`);
  client.user.setPresence({
    activities: [], // ❌ tidak ada Playing
    status: "dnd",  // ✅ Do Not Disturb
  });
});

client.on("guildMemberAdd", (member) => guildMemberAdd(member, welcomeConfig));
client.on("guildMemberRemove", (member) => guildMemberRemove(member, welcomeConfig));

// ================= MESSAGE HANDLER =================
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  const prefix = config.prefix;

  // === AUTO DELETE CAPSLOCK ===
  if (message.content.length > 5) {
    const letters = message.content.replace(/[^a-zA-Z]/g, "");
    if (letters.length > 0) {
      const upperCount = letters.split("").filter((c) => c === c.toUpperCase()).length;
      const upperRatio = upperCount / letters.length;

      if (upperRatio > 0.7 && !message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        try {
          await message.delete();
        } catch (err) {
          console.error("Failed to delete CAPSLOCK message:", err);
        }
      }
    }
  }

  // === AFK CHECK ===
  const afkCommand = client.commands.get("afk");
  if (afkCommand && afkCommand.afkMap) {
    message.mentions.users.forEach((user) => {
      const afk = afkCommand.afkMap.get(user.id);
      if (afk) message.channel.send(`📴 ${user.tag} sedang AFK — ${afk.reason}`);
    });

    if (afkCommand.afkMap.has(message.author.id)) {
      afkCommand.afkMap.delete(message.author.id);
      message.reply("✅ Status AFK kamu telah dinonaktifkan.");
    }
  }

  // === COMMAND PARSER ===
  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  // Auto trigger jika command = nama bot
  if (client.user && commandName === client.user.username.toLowerCase()) {
    const botCommand = client.commands.get("bot");
    if (botCommand) return botCommand.execute(message, args);
  }

  // === GANTI PREFIX ===
  if (commandName === "prefix") {
    const newPrefix = args[0];
    if (!newPrefix) return message.reply(`❌ Masukkan prefix baru. Contoh: \`${prefix}prefix !\``);
    config.prefix = newPrefix;
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    return message.reply(`✅ Prefix berhasil diubah ke \`${newPrefix}\``);
  }

  const command = client.commands.get(commandName);
  if (!command) return;

  try {
    await command.execute(message, args, welcomeConfig, welcomeConfigPath);
  } catch (err) {
    console.error(err);
    message.reply("⚠️ Terjadi error saat menjalankan command.");
  }
});

// ================= INTERACTIONS =================
const ticketButtonHandler = require("./interactions/ticketButton");

client.on("interactionCreate", async (interaction) => {
  // Dropdown role
  if (interaction.isStringSelectMenu() && interaction.customId === "select-role") {
    const selectedRoleId = interaction.values[0];
    const member = interaction.member;
    const role = interaction.guild.roles.cache.get(selectedRoleId);

    if (!role) return interaction.reply({ content: "❌ Role tidak ditemukan.", flags: 64 });

    try {
      if (member.roles.cache.has(role.id)) {
        await member.roles.remove(role);
        return interaction.reply({ content: `✅ Role **${role.name}** telah dihapus dari kamu.`, flags: 64 });
      } else {
        await member.roles.add(role);
        return interaction.reply({ content: `✅ Role **${role.name}** berhasil diberikan!`, flags: 64 });
      }
    } catch (error) {
      console.error("Error saat mengubah role:", error);
      return interaction.reply({
        content: "❌ Gagal mengubah role. Pastikan bot memiliki permission yang cukup.",
        flags: 64,
      });
    }
  }

  // Ticket button
  if (interaction.isButton()) await ticketButtonHandler.execute(interaction);
});

// ================= AUTO DISCONNECT VOICE =================
client.on("voiceStateUpdate", (oldState, newState) => {
  const connection = getVoiceConnection(newState.guild.id);
  if (!connection) return;

  const channel = newState.guild.channels.cache.get(connection.joinConfig.channelId);
  if (!channel) return;

  const nonBotMembers = channel.members.filter((m) => !m.user.bot);
  if (nonBotMembers.size === 0) {
    connection.destroy();

    const textChannel = newState.guild.channels.cache.find(
      (c) => c.isTextBased() && c.permissionsFor(newState.guild.members.me).has(PermissionsBitField.Flags.SendMessages)
    );
    if (textChannel) textChannel.send("⏹️ Bot keluar dari voice channel karena sudah ditinggal sendiri.");
  }
});

// ================= LOAD EVENTS =================
const eventsPath = path.join(__dirname, "events");
fs.readdirSync(eventsPath).forEach((file) => {
  const event = require(path.join(eventsPath, file));
  if (event && event.name && typeof event.execute === "function") {
    client.on(event.name, (...args) => event.execute(client, ...args));
  }
});

// ================= VALIDATE COMMANDS =================
async function validateCommands(client) {
  let validCount = 0;
  let invalid = [];

  console.log("\n🔍 Validating commands...\n");
  console.log("╔═════════════════════════╦═════════╗");
  console.log("║ Command Name            ║  Status ║");
  console.log("╠═════════════════════════╬═════════╣");

  for (const [name, command] of client.commands) {
    if (command && typeof command.execute === "function") {
      validCount++;
      console.log(`║ ${name.padEnd(23)} ║  Valid  ║`);
    } else {
      invalid.push(name);
      console.log(`║ ${name.padEnd(23)} ║ Invalid ║`);
    }
  }

  console.log("╚═════════════════════════╩═════════╝\n");
  console.log(`Summary: ${validCount} valid, ${invalid.length} invalid`);

  if (invalid.length > 0) {
    console.log("⚠️ Check these commands:");
    invalid.forEach((cmd) => console.log(` - ${cmd}`));
  }

  return invalid.length === 0;
}

// ================= START BOT =================
(async () => {
  const isValid = await validateCommands(client);
  if (!isValid) {
    console.log("❌ Bot tidak login karena ada command invalid.");
    process.exit(1);
  }

  client.login(config.token);
})();