const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  EmbedBuilder
} = require('discord.js');
const fs = require('fs');

module.exports = {
  name: 'ticketButtonHandler',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    const ticketConfigPath = './ticketConfig.json';
    let ticketConfig = {};

    try {
      if (fs.existsSync(ticketConfigPath)) {
        const data = fs.readFileSync(ticketConfigPath, 'utf8');
        ticketConfig = data ? JSON.parse(data) : {};
      }
    } catch (error) {
      console.error('Error reading ticketConfig.json:', error);
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setTitle('❌ Kesalahan')
            .setDescription('Terjadi kesalahan konfigurasi tiket.')
        ],
        flags: 64
      });
    }

    const guildId = interaction.guild.id;
    const config = ticketConfig[guildId];
    if (!config || !config.categoryId) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Orange')
            .setTitle('⚠️ Sistem Ticket Belum Disiapkan')
            .setDescription('Gunakan command setup dulu.')
        ],
        flags: 64
      });
    }

    // CREATE TICKET
    if (interaction.customId === 'create_ticket') {
      const existingChannel = interaction.guild.channels.cache.find(
        c => c.name === `ticket-${interaction.user.username.toLowerCase()}` && c.parentId === config.categoryId
      );

      if (existingChannel) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setTitle('❌ Ticket Sudah Ada')
              .setDescription(`Kamu sudah memiliki ticket: ${existingChannel}`)
          ],
          flags: 64
        });
      }

      const staffRoles = interaction.guild.roles.cache.filter(role =>
        role.permissions.has(PermissionFlagsBits.ManageChannels) ||
        role.permissions.has(PermissionFlagsBits.ManageGuild)
      );

      const permissionOverwrites = [
        {
          id: interaction.guild.roles.everyone.id,
          deny: ['ViewChannel']
        },
        {
          id: interaction.user.id,
          allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
        }
      ];

      staffRoles.forEach(role => {
        permissionOverwrites.push({
          id: role.id,
          allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
        });
      });

      try {
        const ticketChannel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username.toLowerCase()}`,
          type: 0,
          parent: config.categoryId,
          permissionOverwrites
        });

        await interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Green')
              .setTitle('✅ Ticket Dibuat')
              .setDescription(`Ticket kamu sudah dibuat: ${ticketChannel}`)
          ],
          flags: 64
        });

        const actionRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('🔒 Close')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId('save_ticket')
            .setLabel('💾 Transcript')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('🗑️ Delete')
            .setStyle(ButtonStyle.Secondary)
        );

        const ticketEmbed = new EmbedBuilder()
          .setColor('Blue')
          .setTitle('🎟️ Ticket Support')
          .setDescription(`Halo ${interaction.user}, silahkan tag staff agar tiket kamu segera ditanggapi.`)
          .setTimestamp();

        await ticketChannel.send({ embeds: [ticketEmbed], components: [actionRow] });
      } catch (error) {
        console.error(error);
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Red')
              .setTitle('❌ Gagal Membuat Ticket')
              .setDescription('Terjadi kesalahan saat membuat ticket.')
          ],
          flags: 64
        });
      }
    }

    // SAVE TICKET
    if (interaction.customId === 'save_ticket') {
      if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setTitle('❌ Bukan Channel Ticket')
              .setDescription('Kamu hanya dapat menyimpan channel ticket.')
          ],
          flags: 64
        });
      }

      try {
        let transcriptCategory = interaction.guild.channels.cache.find(
          c => c.type === 4 && c.name.toLowerCase() === 'transkrip'
        );
        if (!transcriptCategory) {
          transcriptCategory = await interaction.guild.channels.create({
            name: 'Transkrip',
            type: 4,
            permissionOverwrites: [
              {
                id: interaction.guild.roles.everyone.id,
                deny: ['ViewChannel']
              }
            ]
          });
        }

        const staffRoles = interaction.guild.roles.cache.filter(role =>
          role.permissions.has(PermissionFlagsBits.ManageChannels) ||
          role.permissions.has(PermissionFlagsBits.ManageGuild)
        );

        const permissionOverwrites = [
          {
            id: interaction.guild.roles.everyone.id,
            deny: ['ViewChannel']
          }
        ];

        staffRoles.forEach(role => {
          permissionOverwrites.push({
            id: role.id,
            allow: ['ViewChannel']
          });
        });

        permissionOverwrites.push({
          id: interaction.user.id,
          allow: ['ViewChannel']
        });

        await interaction.channel.edit({
          parent: transcriptCategory.id,
          permissionOverwrites
        });

        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Green')
              .setTitle('💾 Ticket Disimpan')
              .setDescription('Ticket berhasil dipindahkan ke kategori Transkrip.')
          ],
          flags: 64
        });
      } catch (error) {
        console.error(error);
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Red')
              .setTitle('❌ Gagal Menyimpan Ticket')
              .setDescription('Terjadi kesalahan saat menyimpan ticket.')
          ],
          flags: 64
        });
      }
    }

    // CLOSE TICKET
    if (interaction.customId === 'close_ticket') {
      if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setTitle('❌ Bukan Channel Ticket')
              .setDescription('Kamu tidak dapat menutup channel ini karena bukan ticket.')
          ],
          flags: 64
        });
      }

      try {
        await interaction.channel.delete();
      } catch (error) {
        console.error(error);
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Red')
              .setTitle('❌ Gagal Menghapus Channel')
              .setDescription('Terjadi kesalahan saat menghapus channel ticket.')
          ],
          flags: 64
        });
      }
    }

    // DELETE TICKET
    if (interaction.customId === 'delete_ticket') {
      if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setTitle('❌ Bukan Channel Ticket')
              .setDescription('Channel ini bukan ticket.')
          ],
          flags: 64
        });
      }

      try {
        await interaction.channel.delete();
      } catch (error) {
        console.error('Error deleting ticket:', error);
      }
    }
  }
};
