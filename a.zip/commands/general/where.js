const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'where',
  description: 'Menampilkan lokasi voice channel user saat ini.',
  category: 'Utility',

  async execute(message, args) {
    let user;

    // Coba ambil user dari mention atau ID, jika tidak ada gunakan author
    if (args.length > 0) {
      const id = args[0].replace(/[<@!>]/g, '');
      try {
        user = await message.client.users.fetch(id);
      } catch {
        return message.reply('❌ Tidak dapat menemukan user dengan ID tersebut.');
      }
    } else {
      user = message.author;
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) return message.reply('❌ User tidak ditemukan di server ini.');

    const voiceChannel = member.voice.channel;
    if (!voiceChannel) {
      return message.reply(`🔇 **${user.username}** tidak sedang berada di voice channel manapun.`);
    }

    const memberCount = voiceChannel.members.size;

    const embed = new EmbedBuilder()
      .setAuthor({
        name: `${user.username} sedang berada di Voice Channel`,
        iconURL: user.displayAvatarURL({ dynamic: true }),
      })
      .setColor('#5865F2')
      .setDescription(
        `🎧 Channel: <#${voiceChannel.id}>\n👥 User Voice: **${memberCount}**\n🔗 ID: \`${voiceChannel.id}\``
      )
      .setFooter({
        text: `Diminta oleh ${message.author.tag}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
