const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'serverinfo',
  description: 'Menampilkan informasi server.',
  category: 'Utility',
  execute(message) {
    const { guild } = message;

    const embed = new EmbedBuilder()
      .setTitle(`🌐 Informasi Server: ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 512 }))
      .setColor('#2ECC71') // Warna hijau segar
      .addFields(
        { name: '👑 Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: '👥 Member', value: `${guild.memberCount}`, inline: true },
        { name: '📅 Dibuat', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D> (<t:${Math.floor(guild.createdTimestamp / 1000)}:R>)`, inline: false },
        { name: '🎭 Role', value: `${guild.roles.cache.size}`, inline: true },
        { name: '📂 Channel', value: `${guild.channels.cache.size}`, inline: true },
        { name: '🌍 Region', value: guild.preferredLocale || 'Tidak tersedia', inline: true },
        { name: '🔒 Verification Level', value: guild.verificationLevel.toString(), inline: true }
      )
      .setFooter({ text: `Server ID: ${guild.id}` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};