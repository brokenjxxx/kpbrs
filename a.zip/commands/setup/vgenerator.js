const { ChannelType, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { category } = require('../general/afk');

module.exports = {
  name: 'vgenerator',
  description: 'Membuat Voice Generator **Tahap Pembuatan**',
  category: 'Utility',

  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('❌ Kamu butuh permission Administrator untuk command ini.');
    }

    const categoryId = args[0];
    if (!categoryId) {
      return message.reply('❌ Harap masukkan ID kategori. Contoh: `!vgenerator <ID_KATEGORI>`');
    }

    const category = message.guild.channels.cache.get(categoryId);
    if (!category || category.type !== ChannelType.GuildCategory) {
      return message.reply('❌ Kategori tidak valid. Pastikan ID kategori yang diberikan benar.');
    }

    const existingVoice = message.guild.channels.cache.find(
      (c) => c.name === '➕ Create Room' && c.type === ChannelType.GuildVoice
    );

    if (existingVoice) {
      return message.reply('⚠️ Voice generator sudah disiapkan.');
    }

    try {
      const channel = await message.guild.channels.create({
        name: '➕ Create Room',
        type: ChannelType.GuildVoice,
        parent: categoryId,
        permissionOverwrites: [
          {
            id: message.guild.roles.everyone,
            allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.ViewChannel],
          },
        ],
      });

      message.reply(`✅ Channel **${channel.name}** berhasil dibuat di kategori **${category.name}**!`);
    } catch (error) {
      console.error(error);
      return message.reply('⚠️ Terjadi kesalahan saat membuat channel.');
    }
  },

  async handleVoiceStateUpdate(oldState, newState) {
    const createRoomChannelName = '➕ Create Room';

    if (newState.channel && newState.channel.name === createRoomChannelName) {
      const guild = newState.guild;
      const member = newState.member;

      try {
        const tempChannel = await guild.channels.create({
          name: `🔊  ${member.user.username}`,
          type: ChannelType.GuildVoice,
          parent: newState.channel.parent,
          permissionOverwrites: [
            {
              id: guild.id, 
              allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.ViewChannel],
            },
            {
              id: member.id, 
              allow: [PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MoveMembers],
            },
          ],
        });

        await member.voice.setChannel(tempChannel);

        const interval = setInterval(async () => {
          if (tempChannel.members.size === 0) {
            clearInterval(interval);
            await tempChannel.delete().catch(console.error);
          }
        }, 5000); // Cek setiap 5 detik
      } catch (error) {
        console.error('Error saat membuat room temporary:', error);
      }
    }
  },
};
