const { PermissionsBitField } = require('discord.js');
const ms = require('ms'); 

const warnings = {};

module.exports = {
  name: 'moderation',
  description: 'Command moderation seperti ban, kick, mute, warn, clear',
  category: 'Moderation',
  async execute(message, args) {

    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('🚫 Kamu tidak diperizinkan untuk menjalankan perintah ini.');
    }

    const subCommand = args.shift()?.toLowerCase();
    if (!subCommand) {
      return message.reply('Gunakan: ban/kick/mute/unmute/warn/warnings/clear');
    }

    if (subCommand === 'ban') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) return message.reply('⚠️ Kamu tidak punya izin Ban Members!');
      const user = message.mentions.members.first();
      if (!user) return message.reply('❌ Sebutkan user yang mau di-ban!');
      if (!user.bannable) return message.reply('❌ Aku tidak bisa ban user ini!');
      const reason = args.join(' ') || 'Tidak ada alasan';
      await user.ban({ reason });
      message.channel.send(`✅ User ${user.user.tag} telah di-ban. Alasan: ${reason}`);

    } else if (subCommand === 'kick') {
      if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return message.reply('⚠️ Kamu tidak punya izin Kick Members!');
      const user = message.mentions.members.first();
      if (!user) return message.reply('❌ Sebutkan user yang mau di-kick!');
      if (!user.kickable) return message.reply('❌ Aku tidak bisa kick user ini!');
      const reason = args.join(' ') || 'Tidak ada alasan';
      await user.kick(reason);
      message.channel.send(`✅ User ${user.user.tag} telah di-kick. Alasan: ${reason}`);

    } else if (subCommand === 'mute') {
      const user = message.mentions.members.first();
      if (!user) return message.reply('❌ Sebutkan user yang mau di-mute!');
      const muteRole = message.guild.roles.cache.find(r => r.name === 'Muted');
      if (!muteRole) return message.reply('⚠️ Role "Muted" tidak ditemukan, silakan buat dulu role "Muted".');
      const duration = args[1] ? ms(args[1]) : null;
      if (user.roles.cache.has(muteRole.id)) return message.reply('⚠️ User sudah dalam keadaan mute!');
      await user.roles.add(muteRole);
      message.channel.send(`✅ User ${user.user.tag} telah di-mute${duration ? ` selama ${args[1]}` : ''}`);

      if (duration) {
        setTimeout(async () => {
          if (user.roles.cache.has(muteRole.id)) {
            await user.roles.remove(muteRole);
            message.channel.send(`⏰ Mute selesai untuk user ${user.user.tag}`);
          }
        }, duration);
      }

    } else if (subCommand === 'unmute') {
      const user = message.mentions.members.first();
      if (!user) return message.reply('❌ Sebutkan user yang mau di-unmute!');
      const muteRole = message.guild.roles.cache.find(r => r.name === 'Muted');
      if (!muteRole) return message.reply('⚠️ Role "Muted" tidak ditemukan.');
      if (!user.roles.cache.has(muteRole.id)) return message.reply('⚠️ User tidak dalam keadaan mute!');
      await user.roles.remove(muteRole);
      message.channel.send(`✅ User ${user.user.tag} telah di-unmute`);

    } else if (subCommand === 'warn') {
      const user = message.mentions.members.first();
      if (!user) return message.reply('❌ Sebutkan user yang mau di-warn!');
      const reason = args.join(' ') || 'Tidak ada alasan';

      if (!warnings[user.id]) warnings[user.id] = [];
      warnings[user.id].push({ moderator: message.author.tag, reason, date: new Date().toISOString() });

      message.channel.send(`⚠️ User ${user.user.tag} mendapatkan peringatan. Alasan: ${reason}`);

    } else if (subCommand === 'warnings') {
      const user = message.mentions.members.first() || message.member;
      const userWarnings = warnings[user.id] || [];
      if (userWarnings.length === 0) return message.reply('User ini tidak memiliki peringatan.');

      let warnMsg = `⚠️ Peringatan untuk ${user.user.tag}:\n`;
      userWarnings.forEach((w, i) => {
        warnMsg += `${i + 1}. Oleh: ${w.moderator}, Alasan: ${w.reason}, Tanggal: ${new Date(w.date).toLocaleString()}\n`;
      });
      message.channel.send(warnMsg);

    } else if (subCommand === 'clear') {
      const amount = parseInt(args[0]);
      if (!amount || amount < 1 || amount > 100) return message.reply('⚠️ Masukkan jumlah pesan antara 1 sampai 100!');
      await message.channel.bulkDelete(amount + 1, true).catch(() => {
        return message.reply('❌ Tidak bisa menghapus pesan yang lebih dari 14 hari.');
      });
      message.channel.send(`🧹 Berhasil menghapus ${amount} pesan!`).then(msg => setTimeout(() => msg.delete(), 3000));

    } else {
      message.reply('❌ Perintah tidak dikenali. Gunakan: ban/kick/mute/unmute/warn/warnings/clear');
    }
  }
};
