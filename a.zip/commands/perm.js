const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'perm',
  description: 'Menampilkan permission yang dimiliki oleh user (hanya bisa digunakan oleh Administrator).',
  category: 'Utility',
  async execute(message, args) {
    // Cek apakah yang menggunakan perintah ini adalah Administrator
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Kamu harus memiliki izin **Administrator** untuk menggunakan perintah ini.');
    }

    let user;

    // Deteksi target: mention, ID, atau diri sendiri
    if (args.length > 0) {
      const id = args[0].replace(/[<@!>]/g, '');
      try {
        user = await message.client.users.fetch(id);
      } catch (e) {
        return message.reply('❌ Tidak dapat menemukan user dengan ID tersebut.');
      }
    } else {
      user = message.author;
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) return message.reply('❌ User tidak ditemukan di server ini.');

    const permissions = member.permissions.toArray();

    const categorizedPerms = {
      '🔧 Admin': [],
      '🛡️ Management': [],
      '💬 Messaging': [],
      '📁 Channel Access': [],
      '🎵 Voice': [],
      '📦 Other': []
    };

    permissions.forEach(perm => {
      const readable = formatPermission(perm);

      if (perm === 'ADMINISTRATOR') {
        categorizedPerms['🔧 Admin'].push(readable);
      } else if (
        perm.includes('MANAGE') ||
        perm === 'BAN_MEMBERS' ||
        perm === 'KICK_MEMBERS'
      ) {
        categorizedPerms['🛡️ Management'].push(readable);
      } else if (
        perm.includes('MESSAGE') ||
        perm.includes('MENTION') ||
        perm.includes('EMBED') ||
        perm.includes('REACTIONS') ||
        perm.includes('ATTACH')
      ) {
        categorizedPerms['💬 Messaging'].push(readable);
      } else if (
        perm.includes('CHANNEL') ||
        perm.includes('VIEW') ||
        perm.includes('CREATE') ||
        perm === 'USE_APPLICATION_COMMANDS'
      ) {
        categorizedPerms['📁 Channel Access'].push(readable);
      } else if (
        perm.includes('VOICE') ||
        perm.includes('SPEAK') ||
        perm.includes('STREAM')
      ) {
        categorizedPerms['🎵 Voice'].push(readable);
      } else {
        categorizedPerms['📦 Other'].push(readable);
      }
    });

    const embed = new EmbedBuilder()
      .setTitle(`🔐 Permissions dari ${user.username}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setColor('Aqua')
      .setFooter({
        text: `Diminta oleh ${message.author.tag}`,
        iconURL: message.author.displayAvatarURL()
      })
      .setTimestamp();

    for (const [label, perms] of Object.entries(categorizedPerms)) {
      if (perms.length > 0) {
        embed.addFields({
          name: label,
          value: perms.map(p => `• ${p}`).join('\n'),
          inline: false
        });
      }
    }

    message.channel.send({ embeds: [embed] });
  }
};

// Fungsi untuk memformat nama permission agar lebih readable
function formatPermission(perm) {
  return perm
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/\b\w/g, l => l.toUpperCase());
}
