module.exports = {
  name: 'clear',
  description: 'Menghapus sejumlah pesan dari channel.',
  category: 'Utility',
  async execute(message, args) {
    if (!message.member.permissions.has('ManageMessages')) {
      return message.reply('❌ Kamu tidak punya izin untuk menghapus pesan!');
    }

    if (!message.guild.members.me.permissions.has('ManageMessages')) {
      return message.reply('❌ Bot tidak memiliki izin untuk menghapus pesan!');
    }

    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount < 1 || amount > 100) {
      return message.reply('❌ Masukkan jumlah pesan yang valid (1 - 100).');
    }

    try {
      // Batasi supaya max 100, termasuk pesan perintah
      const toDelete = amount >= 100 ? 100 : amount + 1;
      const deleted = await message.channel.bulkDelete(toDelete, true);

      const replyMsg = await message.channel.send(`🧹 ${deleted.size} pesan berhasil dihapus.`);
      setTimeout(() => {
        replyMsg.delete().catch(() => {});
      }, 5000);
    } catch (error) {
      if (error.code === 50013) {
        message.channel.send('❌ Bot tidak memiliki izin untuk menghapus pesan.').catch(() => {});
      } else if (error.code === 10008) {
        console.warn('⚠️ Beberapa pesan tidak ditemukan atau sudah dihapus.');
      } else {
        console.error('❌ Terjadi kesalahan saat menghapus pesan:', error);
        message.channel.send('⚠️ Terjadi kesalahan saat mencoba menghapus pesan.').catch(() => {});
      }
    }
  }
};
