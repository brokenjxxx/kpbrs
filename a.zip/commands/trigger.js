const fs = require('fs');
const { description, category } = require('./afk');
const triggerFile = './triggers.json';

function loadTriggers() {
  if (!fs.existsSync(triggerFile)) return {};
  return JSON.parse(fs.readFileSync(triggerFile, 'utf8'));
}

function saveTriggers(data) {
  fs.writeFileSync(triggerFile, JSON.stringify(data, null, 2));
}

module.exports = {
  name: 'trigger',
  description: 'Trigger Bot',
  category: 'Fun',
  async execute(message, args) {
    const guildId = message.guild.id;
    const triggers = loadTriggers();
    if (!triggers[guildId]) triggers[guildId] = {};

    const subcommand = args[0]?.toLowerCase();

    if (subcommand === 'add') {
      if (!message.member.permissions.has('ManageGuild')) {
        return message.reply('❌ Kamu tidak punya izin.');
      }

      const key = args[1]?.toLowerCase();
      const value = args.slice(2).join(' ');
      if (!key || !value) {
        return message.reply('❌ Format: `!trigger add <kata> <respon>`');
      }

      triggers[guildId][key] = value;
      saveTriggers(triggers);
      return message.reply(`✅ Trigger \`${key}\` disimpan dengan respon: \`${value}\``);
    }

    if (subcommand === 'remove') {
      if (!message.member.permissions.has('ManageGuild')) {
        return message.reply('❌ Kamu tidak punya izin.');
      }

      const key = args[1]?.toLowerCase();
      if (!triggers[guildId][key]) {
        return message.reply(`⚠️ Trigger \`${key}\` tidak ditemukan.`);
      }

      delete triggers[guildId][key];
      saveTriggers(triggers);
      return message.reply(`🗑️ Trigger \`${key}\` berhasil dihapus.`);
    }

    if (subcommand === 'list') {
      const list = Object.entries(triggers[guildId])
        .map(([k, v]) => `🔹 \`${k}\` → ${v}`)
        .join('\n') || 'Tidak ada trigger';

      return message.reply(`📋 **Daftar Trigger:**\n${list}`);
    }

    // Bantuan
    return message.reply('❓ Gunakan:\n`!trigger add <kata> <respon>`\n`!trigger remove <kata>`\n`!trigger list`');
  }
};
