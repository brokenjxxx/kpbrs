const fs = require("fs");
const path = require("path");

module.exports = {
  name: "addrole",
  description: "Menambahkan role ke daftar whitelist.",
  async execute(message, args) {
    // Cegah eksekusi di DM
    if (!message.guild) {
      return message.reply("❌ Command ini hanya bisa digunakan di dalam server, bukan di DM.");
    }

    // Pastikan member valid
    if (!message.member) {
      return message.reply("⚠️ Terjadi error: data member tidak ditemukan.");
    }

    // Pastikan punya izin
    if (!message.member.permissions.has("Administrator")) {
      return message.reply("❌ Kamu tidak memiliki izin Administrator untuk menambahkan role whitelist.");
    }

    // Ambil role yang di-mention
    const role = message.mentions.roles.first();
    if (!role) {
      return message.reply("❌ Harap tag role yang ingin ditambahkan ke whitelist. Contoh: `..addrole @role`");
    }

    // Path whitelist.json
    const whitelistPath = path.join(__dirname, "../../data/whitelist.json");
    let whitelistData = { users: [], roles: [] };

    // Baca file whitelist
    if (fs.existsSync(whitelistPath)) {
      try {
        const data = fs.readFileSync(whitelistPath, "utf8");
        whitelistData = JSON.parse(data || "{}");
        if (!whitelistData.roles) whitelistData.roles = [];
        if (!whitelistData.users) whitelistData.users = [];
      } catch (err) {
        console.error("❌ Gagal membaca whitelist.json:", err);
      }
    }

    // Tambahkan role jika belum ada
    if (!whitelistData.roles.includes(role.id)) {
      whitelistData.roles.push(role.id);
      fs.writeFileSync(whitelistPath, JSON.stringify(whitelistData, null, 2));
      return message.reply(`✅ Role **${role.name}** telah ditambahkan ke whitelist.`);
    } else {
      return message.reply(`⚠️ Role **${role.name}** sudah ada di whitelist.`);
    }
  },
};
