const fs = require("fs");
const path = require("path");

module.exports = {
  name: "removerole",
  description: "Menghapus role dari daftar whitelist.",
  async execute(message, args) {
    // Cegah penggunaan di DM
    if (!message.guild) {
      return message.reply("❌ Command ini hanya bisa digunakan di dalam server, bukan di DM.");
    }

    // Cegah jika data member tidak tersedia
    if (!message.member) {
      return message.reply("⚠️ Terjadi error: data member tidak ditemukan.");
    }

    // Cek permission
    if (!message.member.permissions.has("Administrator")) {
      return message.reply("❌ Kamu tidak memiliki izin Administrator untuk menghapus role dari whitelist.");
    }

    // Ambil role yang di-mention
    const role = message.mentions.roles.first();
    if (!role) {
      return message.reply("❌ Harap tag role yang ingin dihapus dari whitelist. Contoh: `..removerole @role`");
    }

    // Path file whitelist
    const whitelistPath = path.join(__dirname, "../../data/whitelist.json");
    let whitelistData = { users: [], roles: [] };

    // Baca whitelist.json jika ada
    if (fs.existsSync(whitelistPath)) {
      try {
        const data = fs.readFileSync(whitelistPath, "utf8");
        whitelistData = JSON.parse(data || "{}");
        if (!whitelistData.roles) whitelistData.roles = [];
        if (!whitelistData.users) whitelistData.users = [];
      } catch (err) {
        console.error("❌ Gagal membaca whitelist.json:", err);
      }
    }

    // Hapus role dari whitelist jika ada
    if (whitelistData.roles.includes(role.id)) {
      whitelistData.roles = whitelistData.roles.filter((id) => id !== role.id);
      fs.writeFileSync(whitelistPath, JSON.stringify(whitelistData, null, 2));
      return message.reply(`✅ Role **${role.name}** telah dihapus dari whitelist.`);
    } else {
      return message.reply(`⚠️ Role **${role.name}** tidak ditemukan di whitelist.`);
    }
  },
};
