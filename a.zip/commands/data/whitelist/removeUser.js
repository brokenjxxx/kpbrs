const fs = require("fs");
const path = require("path");

module.exports = {
  name: "removeuser",
  description: "Menghapus user dari whitelist.",
  async execute(message, args) {
    // Pastikan command dijalankan di server, bukan DM
    if (!message.guild) {
      return message.reply("❌ Command ini hanya bisa digunakan di dalam server, bukan di DM.");
    }

    // Pastikan member data ada
    if (!message.member) {
      return message.reply("⚠️ Terjadi error: data member tidak ditemukan.");
    }

    // Cek permission admin
    if (!message.member.permissions.has("Administrator")) {
      return message.reply("❌ Kamu tidak memiliki izin Administrator untuk menghapus whitelist.");
    }

    // Ambil user yang di-mention
    const user = message.mentions.users.first();
    if (!user) {
      return message.reply("❌ Harap tag user yang ingin dihapus dari whitelist. Contoh: `..removeuser @user`");
    }

    // Path file whitelist.json
    const whitelistPath = path.join(__dirname, "../../data/whitelist.json");
    let whitelistData = { users: [], roles: [] };

    // Baca whitelist
    if (fs.existsSync(whitelistPath)) {
      try {
        const data = fs.readFileSync(whitelistPath, "utf8");
        whitelistData = JSON.parse(data || "{}");
        if (!whitelistData.users) whitelistData.users = [];
        if (!whitelistData.roles) whitelistData.roles = [];
      } catch (err) {
        console.error("❌ Gagal membaca whitelist.json:", err);
      }
    }

    // Cek apakah user ada di whitelist
    if (whitelistData.users.includes(user.id)) {
      whitelistData.users = whitelistData.users.filter((id) => id !== user.id);
      fs.writeFileSync(whitelistPath, JSON.stringify(whitelistData, null, 2));
      return message.reply(`✅ User ${user.tag} telah dihapus dari whitelist.`);
    } else {
      return message.reply(`⚠️ User ${user.tag} tidak ada di whitelist.`);
    }
  },
};
