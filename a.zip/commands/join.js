const { joinVoiceChannel } = require('@discordjs/voice');

module.exports = {
  name: 'join',
  description: 'Join voice channel',
  category: 'Fun',
  async execute(message, args) {
    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) return message.reply('❌ Kamu harus ada di voice channel dulu!');

    try {
      joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: message.guild.id,
        adapterCreator: message.guild.voiceAdapterCreator,
        selfDeaf: false,
      });
      message.reply(`✅ Bergabung ke channel: ${voiceChannel.name}`);
    } catch (error) {
      console.error(error);
      message.reply('❌ Gagal masuk ke voice channel.');
    }
  },
};